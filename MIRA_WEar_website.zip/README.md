# MIRA WEAR — Store + VIP/Rewards

Iyi ni version ya mbere ya MIRA WEAR ikora nka frontend website kandi ibika demo data muri browser `localStorage`.

## Ibyubatswemo
- Fashion store
- Products/categories/search
- Cart & checkout
- MoMo payment instructions: 0799538919
- Welcome Bonus 2,000 RWF
- Daily Check-in 100 RWF
- Gift Code demo: MIRA200 = 200 RWF
- VIP 1: 5,000 RWF / reward example 1,000 RWF
- VIP 2: 10,000 RWF / reward example 1,800 RWF
- Referral/commission display
- Wallet
- Withdrawal request demo
- Responsive mobile/desktop design

## Gufungura
Fungura `index.html` muri browser.

## Icyitonderwa
Iyi version ntabwo ari payment gateway nyayo kandi ntabwo ifite backend/admin database nyayo. MoMo number igaragara nk'amabwiriza yo kwishyura. Mu production, payment verification, authentication, wallet, commissions na withdrawals bigomba kujya kuri secure backend (urugero Supabase) kandi secrets ntizishyirwe muri frontend.

## Next production step
- Supabase Auth
- Products/orders database
- Admin dashboard
- Secure RLS
- Server-side payment verification
- Real MoMo integration niba API/merchant credentials ziboneka
