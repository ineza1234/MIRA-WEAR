const products=[
{id:1,name:"Black Satin Slip Dress",price:55800,cat:"Abagore",emoji:"👗",tag:"SALE"},
{id:2,name:"Red Bodycon Dress",price:32300,cat:"Abagore",emoji:"👗",tag:"SALE"},
{id:3,name:"Elegant Gold Accessories",price:12000,cat:"Accessories",emoji:"💎",tag:"FEATURED"},
{id:4,name:"Floral Red Dress",price:45000,cat:"Abagore",emoji:"👚",tag:"FEATURED"},
{id:5,name:"Classic Men's Shirt",price:28000,cat:"Abagabo",emoji:"👔",tag:"NEW"},
{id:6,name:"MIRA Premium Bag",price:38000,cat:"Accessories",emoji:"👜",tag:"NEW"},
{id:7,name:"VIP 1 Reward Package",price:5000,cat:"VIP",emoji:"💎",tag:"VIP 1"},
{id:8,name:"VIP 2 Reward Package",price:10000,cat:"VIP",emoji:"👑",tag:"VIP 2"}
];
let state=JSON.parse(localStorage.getItem("miraWearState")||'null')||{cart:[],balance:0,commission:0,vip:0,referrals:0,welcome:false,lastCheckin:null,history:[]};
let category="All";
const rwf=n=>new Intl.NumberFormat("en-US").format(n)+" RWF";
function save(){localStorage.setItem("miraWearState",JSON.stringify(state));renderAll()}
function toast(t){const e=document.getElementById("toast");e.textContent=t;e.style.display="block";setTimeout(()=>e.style.display="none",2500)}
function setCategory(c){category=c;renderProducts()}
function renderProducts(){
 const q=(document.getElementById("search")?.value||"").toLowerCase();
 const list=products.filter(p=>(category==="All"||p.cat===category)&&p.name.toLowerCase().includes(q));
 document.getElementById("products").innerHTML=list.map(p=>`<article class="product"><div class="pic">${p.emoji}</div><div class="info"><span class="tag">${p.tag}</span><h3>${p.name}</h3><div class="price">${rwf(p.price)}</div><button class="btn small" onclick="add(${p.id})">Ongeramo kuri Cart</button></div></article>`).join("");
}
function add(id){state.cart.push(id);save();toast("Product yongewe kuri Cart.")}
function remove(i){state.cart.splice(i,1);save()}
function renderCart(){
 const el=document.getElementById("cartItems"), items=state.cart.map(id=>products.find(p=>p.id===id));
 if(!items.length){el.innerHTML='<div class="empty">Cart irimo ubusa. Jya kuri Shop uhitemo product.</div>';document.getElementById("total").textContent=rwf(0);return}
 el.innerHTML=items.map((p,i)=>`<div class="cart-row"><span>${p.emoji} ${p.name}</span><b>${rwf(p.price)} <button onclick="remove(${i})">×</button></b></div>`).join("");
 document.getElementById("total").textContent=rwf(items.reduce((a,p)=>a+p.price,0));
}
function renderRewards(){
 document.getElementById("balance").textContent=rwf(state.balance);
 document.getElementById("commission").textContent=rwf(state.commission);
 document.getElementById("vip").textContent="VIP "+state.vip;
 document.getElementById("referrals").textContent=state.referrals;
 document.getElementById("history").innerHTML=state.history.length?state.history.slice().reverse().map(x=>`<p>• ${x}</p>`).join(""):"<p>Nta transactions zirabikwa.</p>";
}
function claimWelcome(){if(state.welcome)return toast("Welcome Bonus waramaze gufatwa.");state.welcome=true;state.balance+=2000;state.history.push("Welcome Bonus +2,000 RWF");save();toast("Welcome Bonus ya 2,000 RWF yashyizwe kuri wallet.")}
function checkin(){const today=new Date().toISOString().slice(0,10);if(state.lastCheckin===today)return toast("Wamaze gukora Check-in uyu munsi.");state.lastCheckin=today;state.balance+=100;state.history.push("Daily Check-in +100 RWF");save();toast("Check-in yakozwe: +100 RWF")}
function redeemGift(){const v=document.getElementById("gift").value.trim();if(!v)return toast("Andika Gift Code.");if(v.toUpperCase()==="MIRA200"){state.balance+=200;state.history.push("Gift Code +200 RWF");save();toast("Gift Code yemerewe: +200 RWF")}else toast("Gift Code ntabwo ari valid.")}
function showVip(){toast("VIP 1 = 5,000 RWF / reward 1,000. VIP 2 = 10,000 / reward 1,800.")}
function copyRef(){navigator.clipboard?.writeText(document.getElementById("refLink").textContent);toast("Referral code copied.")}
function withdraw(){const a=Number(document.getElementById("withdrawAmount").value),m=document.getElementById("momo").value.trim();if(!a||a<=0||a>state.balance)return toast("Amount ntabwo ari valid cyangwa irenze wallet.");if(!m)return toast("Shyiramo MoMo number.");state.balance-=a;state.history.push(`Withdrawal request: ${rwf(a)} kuri ${m} — Pending`);save();toast("Withdrawal request yoherejwe kuri Pending.")}
function placeOrder(){const name=document.getElementById("customerName").value.trim(),phone=document.getElementById("customerPhone").value.trim(),addr=document.getElementById("address").value.trim(),tx=document.getElementById("txid").value.trim();if(!state.cart.length)return toast("Cart irimo ubusa.");if(!name||!phone||!addr)return toast("Uzuza amazina, telephone na address.");const total=state.cart.reduce((a,id)=>a+products.find(p=>p.id===id).price,0);const order="MW-"+Date.now().toString().slice(-7);state.history.push(`Order ${order}: ${rwf(total)} — Payment ${tx?"Submitted":"Pending"}`);state.cart=[];save();toast(`Order ${order} yakozwe. MoMo: 0799538919`)}
function renderAll(){renderProducts();renderCart();renderRewards();document.getElementById("cartCount").textContent=state.cart.length}
function toggleMenu(){document.querySelector("nav").style.display=document.querySelector("nav").style.display==="flex"?"none":"flex"}
renderAll();
