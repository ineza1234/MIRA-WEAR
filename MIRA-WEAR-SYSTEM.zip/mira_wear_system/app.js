const DEFAULT_PRODUCTS=[
{id:1,name:'Pink Elegance Dress',price:45000,stock:8,image:img('Pink Dress','f6a3c2')},
{id:2,name:'Classic Black Dress',price:38000,stock:7,image:img('Black Dress','3a3035')},
{id:3,name:'Brown Chic Set',price:42000,stock:6,image:img('Brown Set','8d5a42')},
{id:4,name:'White Luxury Shirt',price:25000,stock:10,image:img('White Shirt','e9e9e9')},
{id:5,name:'Yellow Summer Dress',price:35000,stock:9,image:img('Yellow Dress','f4c62f')},
{id:6,name:'Pink Casual Set',price:32000,stock:8,image:img('Pink Set','f09ab8')},
{id:7,name:'Black Elegant Top',price:22000,stock:12,image:img('Black Top','4b4248')},
{id:8,name:'Brown Long Dress',price:40000,stock:5,image:img('Brown Dress','9a6b55')},
{id:9,name:'White Soft Top',price:18000,stock:13,image:img('White Top','f4f2ef')},
{id:10,name:'Yellow Fashion Top',price:23000,stock:9,image:img('Yellow Top','edbd2b')},
{id:11,name:'Pink Party Dress',price:48000,stock:4,image:img('Party Dress','ea7ea8')},
{id:12,name:'MIRA Premium Set',price:55000,stock:4,image:img('Premium Set','b98aa0')}
];
function img(t,c){return `data:image/svg+xml;charset=UTF-8,${encodeURIComponent(`<svg xmlns="http://www.w3.org/2000/svg" width="700" height="700"><rect width="100%" height="100%" fill="#${c}"/><text x="50%" y="48%" text-anchor="middle" font-size="44" font-family="Arial" fill="#fff">MIRA WEAR</text><text x="50%" y="56%" text-anchor="middle" font-size="30" font-family="Arial" fill="#fff">${t}</text></svg>` )}`}
let products=JSON.parse(localStorage.getItem('mira_products')||'null')||DEFAULT_PRODUCTS; localStorage.setItem('mira_products',JSON.stringify(products));
let cart=JSON.parse(localStorage.getItem('mira_cart')||'[]'); const money=n=>new Intl.NumberFormat('en-RW').format(n)+' RWF';
const $=s=>document.querySelector(s); function save(){localStorage.setItem('mira_cart',JSON.stringify(cart))}
function render(filter=''){const q=filter.toLowerCase(); $('#productGrid').innerHTML=products.filter(p=>p.name.toLowerCase().includes(q)).map(p=>`<article class="card"><img src="${p.image}" alt="${p.name}"><div class="pad"><div class="name">${p.name}</div><div class="price">${money(p.price)}</div><div class="row"><span class="muted">Stock: ${p.stock}</span><button class="smallBtn" onclick="add(${p.id})">Add</button></div></div></article>`).join('')||'<p>Nta product yabonetse.</p>'; $('#cartCount').textContent=cart.reduce((s,i)=>s+i.qty,0)}
function add(id){const p=products.find(x=>x.id===id); if(!p||p.stock<1)return alert('Product ntiboneka.'); const c=cart.find(x=>x.id===id); c?c.qty++:cart.push({id,qty:1});save();render();openCart()}
function openCart(){$('#cartDrawer').classList.add('open');renderCart()} function renderCart(){let total=0;$('#cartItems').innerHTML=cart.map(i=>{const p=products.find(x=>x.id===i.id); total+=p.price*i.qty; return `<div class="row" style="padding:10px 0;border-bottom:1px solid #eee"><span>${p.name} × ${i.qty}</span><b>${money(p.price*i.qty)}</b><button onclick="removeItem(${i.id})">×</button></div>`}).join('')||'<p class="muted">Cart irimo ubusa.</p>';$('#cartTotal').textContent=money(total)}
function removeItem(id){cart=cart.filter(x=>x.id!==id);save();render();renderCart()}
$('#cartBtn').onclick=openCart; $('#closeCart').onclick=()=>$('#cartDrawer').classList.remove('open'); $('#search').oninput=e=>render(e.target.value);
$('#sendOrder').onclick=()=>{if(!cart.length)return alert('Banza ushyire product muri cart.');const name=$('#custName').value.trim(),phone=$('#custPhone').value.trim(),address=$('#custAddress').value.trim(),pay=$('#payMethod').value;if(!name||!phone)return alert('Andika amazina na numero ya telephone.');let total=0;const lines=cart.map(i=>{const p=products.find(x=>x.id===i.id);total+=p.price*i.qty;return `${p.name} x${i.qty} = ${money(p.price*i.qty)}`}).join('%0A');const text=`Muraho MIRA WEAR,%0AOrder nshya:%0A${lines}%0ATotal: ${money(total)}%0AUmukiriya: ${name}%0ATel: ${phone}%0AAddress: ${address}%0APayment: ${pay}`;let orders=JSON.parse(localStorage.getItem('mira_orders')||'[]');orders.push({id:Date.now(),name,phone,address,pay,total,items:cart,date:new Date().toISOString(),status:'Pending'});localStorage.setItem('mira_orders',JSON.stringify(orders));window.open(`https://wa.me/250${phone.replace(/^0/,'')}?text=${text}`,'_blank');cart=[];save();render();renderCart();alert('Order yabitswe muri system.');}; render();
