# MIRA WEAR — Complete Starter System

Iyi ni static e-commerce starter system ikoresha browser localStorage, bityo ikorera kuri GitHub Pages nta backend isabwa kuri demo.

## Ibirimo
- Online shop
- 12 starter products
- Product search
- Cart
- Order form
- WhatsApp order
- Momo payment number display
- Admin login
- Add/delete products
- Upload product photos from phone/computer
- Price + stock management
- Orders dashboard
- Status: Pending / Confirmed / Delivered / Cancelled
- Basic commission/VIP settings

## Admin
- URL: `admin.html`
- Default password: `admin123`

## Production note
GitHub Pages + localStorage ntabwo ari backend y'abakiriya benshi. Ku system nyayo ifite login, database, payments za Momo, commission calculations ku bantu benshi, admin roles n'umutekano, huza Supabase/Firebase cyangwa backend API.
