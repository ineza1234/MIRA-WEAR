# MIRA WEAR SYSTEM
Static e-commerce starter with:
- Home / Products / About / Contact
- 6 demo products with images and prices
- Search
- Shopping cart
- Order form
- Mobile Money / Cash option
- Admin panel for adding/deleting products
- Data stored in browser localStorage

Admin: admin / 1234

Note: this is a fully runnable static version. Real online payments, secure admin authentication, database, customer accounts, WhatsApp automation and production order management require a backend (e.g. Supabase/Firebase/Node).
