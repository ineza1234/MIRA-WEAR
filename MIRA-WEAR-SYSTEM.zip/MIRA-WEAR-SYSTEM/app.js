const KEY="miraWearProducts", CART="miraWearCart";
const demo=[
{id:1,name:"Pink Elegant Dress",price:45000,img:"https://images.unsplash.com/photo-1566174053879-31528523f8ae?auto=format&fit=crop&w=700&q=80"},
{id:2,name:"Classic Black Dress",price:38000,img:"https://images.unsplash.com/photo-1539008835657-9e8e9680c956?auto=format&fit=crop&w=700&q=80"},
{id:3,name:"Brown Casual Set",price:32000,img:"https://images.unsplash.com/photo-1483985988355-763728e1935b?auto=format&fit=crop&w=700&q=80"},
{id:4,name:"White Fashion Top",price:22000,img:"https://images.unsplash.com/photo-1496747611176-843222e1e57c?auto=format&fit=crop&w=700&q=80"},
{id:5,name:"Yellow Summer Dress",price:30000,img:"https://images.unsplash.com/photo-1515886657613-9f3515b0c78f?auto=format&fit=crop&w=700&q=80"},
{id:6,name:"Black & White Set",price:41000,img:"https://images.unsplash.com/photo-1525507119028-ed4c629a60a3?auto=format&fit=crop&w=700&q=80"}
];
if(!localStorage.getItem(KEY))localStorage.setItem(KEY,JSON.stringify(demo));
if(!localStorage.getItem(CART))localStorage.setItem(CART,"[]");
const money=n=>n.toLocaleString("en-US")+" RWF";
function getProducts(){return JSON.parse(localStorage.getItem(KEY)||"[]")}
function getCart(){return JSON.parse(localStorage.getItem(CART)||"[]")}
function saveCart(c){localStorage.setItem(CART,JSON.stringify(c))}
function renderProducts(){
 const q=(document.getElementById("search").value||"").toLowerCase();
 const data=getProducts().filter(p=>p.name.toLowerCase().includes(q));
 document.getElementById("productsGrid").innerHTML=data.map(p=>`<article class="card"><img src="${p.img}" alt="${p.name}"><div class="pad"><h3>${p.name}</h3><div class="price">${money(p.price)}</div><p class="muted">MIRA WEAR</p><button class="btn" onclick="addToCart(${p.id})">Ongeramo muri Cart</button></div></article>`).join("");
}
function addToCart(id){const c=getCart();c.push({id});saveCart(c);updateCount();alert("Product yongewemo muri Cart.");}
function updateCount(){document.getElementById("cartCount").textContent=getCart().length}
function openCart(){renderCart();document.getElementById("cartModal").classList.remove("hidden")}
function closeCart(){document.getElementById("cartModal").classList.add("hidden")}
function renderCart(){
 const ps=getProducts(), c=getCart();let total=0;
 document.getElementById("cartItems").innerHTML=c.length?c.map((x,i)=>{const p=ps.find(z=>z.id===x.id); if(!p)return""; total+=p.price; return `<div class="cart-row"><span>${p.name}</span><b>${money(p.price)}</b><button onclick="removeItem(${i})">✕</button></div>`}).join(""):"Cart irimo ubusa.";
 document.getElementById("cartTotal").textContent=money(total);
}
function removeItem(i){const c=getCart();c.splice(i,1);saveCart(c);updateCount();renderCart()}
function placeOrder(e){e.preventDefault();const c=getCart();if(!c.length)return alert("Cart irimo ubusa.");const order={customer:document.getElementById("customerName").value,phone:document.getElementById("customerPhone").value,address:document.getElementById("address").value,payment:document.getElementById("payment").value,items:c,date:new Date().toISOString()};localStorage.setItem("miraLastOrder",JSON.stringify(order));alert("Order yakiriwe. Uzahamagara umukiriya kuri telephone yashyizemo.");saveCart([]);updateCount();closeCart()}
renderProducts();updateCount();